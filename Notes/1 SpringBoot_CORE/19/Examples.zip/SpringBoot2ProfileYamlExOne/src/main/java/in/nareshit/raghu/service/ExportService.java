package in.nareshit.raghu.service;

public interface ExportService {

	public void export();
}
