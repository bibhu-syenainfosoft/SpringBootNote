package in.nareshit.raghu.model;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.ToString;

//ctrl+shift+O
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class Student {

	private Integer sid;
	private String sname;
}
