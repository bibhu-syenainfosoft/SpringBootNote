package com.example.demo;

import java.net.URI;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.loadbalancer.LoadBalancerClient;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

@Component
public class EmpConsumer {
	
	//1. Make DiscoveryClient Autowired
	@Autowired
	private LoadBalancerClient client;
	
	public String getEmpData() {
		
		//2. Fetch List<SI> using producer service Id
		ServiceInstance si = client.choose("BRANCH-APP");
		
		//3. Read URI from SI
		URI uri = si.getUri();
		
		//4. Create and URL
		String url = uri+"/company/register";
		
		//5. Use RestTemplate class to make a request to server
		RestTemplate rt = new RestTemplate();
		ResponseEntity<String> responseEntity = rt.getForEntity(url,String.class);
		String respBody = responseEntity.getBody();
		
		return respBody;
	}
	
	

}
