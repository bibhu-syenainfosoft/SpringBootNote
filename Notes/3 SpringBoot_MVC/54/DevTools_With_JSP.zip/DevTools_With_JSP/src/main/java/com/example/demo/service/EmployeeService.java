package com.example.demo.service;

import com.example.demo.model.Employee;

public interface EmployeeService {
public Integer SaveEmployee(Employee ee);
}
