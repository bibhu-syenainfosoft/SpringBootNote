package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootMVC_ExceptionApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootMVC_ExceptionApplication.class, args);
	}

}
