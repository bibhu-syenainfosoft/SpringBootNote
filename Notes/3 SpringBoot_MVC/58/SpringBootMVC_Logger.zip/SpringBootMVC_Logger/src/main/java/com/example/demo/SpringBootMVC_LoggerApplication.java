package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootMVC_LoggerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootMVC_LoggerApplication.class, args);
	}

}
