package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BatchProcessing1Application {

	public static void main(String[] args) {
		SpringApplication.run(BatchProcessing1Application.class, args);
	}

}
