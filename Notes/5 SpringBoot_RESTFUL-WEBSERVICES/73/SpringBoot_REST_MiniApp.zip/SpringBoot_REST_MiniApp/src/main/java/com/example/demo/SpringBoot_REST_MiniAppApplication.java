package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBoot_REST_MiniAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBoot_REST_MiniAppApplication.class, args);
	}
	

}
